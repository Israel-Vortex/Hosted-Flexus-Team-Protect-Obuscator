if not game:IsLoaded() then
    game.Loaded:Wait()
end

local BASE_URL = "https://raw.githubusercontent.com/Israel-FlexusHub/FlexusHub-x-scripts/refs/heads/main/Official-FlexusHub-Software/Dev-Project/Top-Script/"

-- Diccionario con los PlaceIds y sus respectivos archivos .lua
local games = {
    [135856908115931] = "Duels.lua",
    [142823291]       = "MM2.lua",
    [286090429]       = "Arsenal.lua",
    [125927821145949] = "MOUNTAIN.lua",
    [107778070777162] = "StealanEgg.lua",
}

local scriptFile = games[game.PlaceId]

if scriptFile then
    local success, err = pcall(function()
        loadstring(game:HttpGet(BASE_URL .. scriptFile))()
    end)
    
    if not success then
        warn("[FlexusHub] Error al cargar el script:", err)
    end
else
    warn("[FlexusHub] Juego no registrado o script en mantenimiento.")
end

